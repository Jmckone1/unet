      # -*- coding: utf-8 -*-
"""
@author: Joshua Mckone
"""

# consider changing the outline of the parameters and therefore the other code composites to split the hyperparameters file

# check the hyperparamters used in the regression versus the segmentation and note them down
# check whether the parameter file is saved as a copy so that these changes can be tracked

# Segmentation and regression show similar parameters being the best for each variation - at least on the 
# lr = 0.0003
# weight_decay = 1e-8

class Parameters():
    PRANO_Net = {
        "Global" : {
            "Seed" : 0,
            "device" :"cuda",
            "GPU" : 1,
            "Param_location" : "Code_UNet_2/Code_UNet/Net_modules/Parameters_SEG.py",
            "Debug" : False,
            # UNet | DCSAU 
            "Net" : "UNet"
            },
        "Hyperparameters" : {
            "Cosine_penalty" : 100,
            "Epochs" : 3,
            "Batch_size" : 16,
            "Learning_rate" : 3e-4,
            "Weight_decay" : 1e-8,
            "Betas" : (0.9,0.999),
            "Input_dim" : 4,
            "Label_dim" : 1,
            "Hidden_dim" : 16,
            "Train_split" : 0.7,
            "Validation_split" : 0.1,
            "Test_split" : 0.2,
            "Custom_split" : 0.5,
            "Batch_display_step" : 100, # used in line 228 of Unet_full_train file
            # "Confirm_display_step" : True, # not sure if this is used - will need to check
            "Image_scale" : 1,
            "Image_size" : [240,240],
            "Evaluate" : False,
            "Regress" : False,
            "Allow_update" : True,
            "Use_weights" : False,
            "Apply_Augmentation" : True
            },
        "Train_paths" : {
            "Checkpoint_save" : "Checkpoints/UNet_reprod4",
            "Checkpoint_load" : "Checkpoints/UNet_reprod/Regression/checkpoint_0.pth",
            "Data_path" : "/Brats_2018_4/",#"CT_Dataset/Task06_Lung",#"/Brats_2018/","/Brats_2018_small/"
            "Extensions" : [""]
            },
        "Test_paths" : { # test isnt yet implemented so none of these are used
#             "Checkpoint_load" : "Checkpoints/UNet_H16_M15_C100_LR4/checkpoint_199",
#             "Data_path" : "Task06_Lung",
#             "Predictions_output" : "Predictions/UNet_H16_M15_C100_LR4",
#             "PRANO_save" : "/PRANO",
#             "Image_save" : "/IMAGE"
            }
        }
