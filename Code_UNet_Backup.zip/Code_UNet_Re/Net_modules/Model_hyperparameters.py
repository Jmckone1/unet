      # -*- coding: utf-8 -*-
"""
@author: Joshua Mckone
"""

class Parameters():
    Network = {
        "Global" : {
            "Seed" : 11,
            "device" :"cuda",
            "GPU" : 2,
            "Param_location" : "Code_UNet_2/Code_UNet_Re/Net_modules/Model_hyperparameters.py",
            "Debug" : False,
            "Net" : "UNet",
            "Enable_Determinism" : True
            },
        "Hyperparameters" : {
            "Cosine_penalty" : 100,
            "Epochs" : 10,
            "Batch_size" : 8,
            "Learning_rate" : 3e-4,
            "Weight_decay" : 1e-8,
            "Betas" : (0.9,0.999),
            "Input_dim" : 4,
            "Label_dim" : 1,
            "Hidden_dim" : 16,
            # the splits here dont currently do anything - figure out the best new format for this.
            "Train_split" : [0,1,2,3,4,5,6,7,8,9],
            "Validation_split" : [10,11],
            "Test_split" : [12,13,14],
            "Custom_split" : 0.5,
            ############################################
            "Batch_display_step" : 100,
            "Image_scale" : 1,
            "Image_size" : [240,240],
            "Evaluate" : False,
            "Regress" : False,
            "Allow_update" : True,
            "Use_weights" : False,
            "Apply_Augmentation" : False
            },
        "Train_paths" : {
            "Checkpoint_save" : "Checkpoints/split_test_1/",
            "Checkpoint_load" : "Checkpoints_RANO/Checkpoints/Prano_pretrain_1_C100/checkpoint_40.pth",
            "Data_path" : "/Datasets/Brats_2018_4/", # "/Brats_2018_data/Brats_2018_data",#  "/CT_Dataset/Task06_Lung", #"/Brats_2018_4/", #"/Brats_2018/", #"/Brats_2018_small/"
            "Extensions" : ["/HGG", "/LGG"],
            "Index_Path" : "Training_dataset_15.csv"
            },
        "Test_paths" : {
            },
        "Old_Hyperparameters" : {
            "Index_File" : "/inedx_max_2.npy"
            }
        }