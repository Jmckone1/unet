# -*- coding: utf-8 -*-
"""
Created on Fri Jan 20 11:17:55 2023

@author: Computing
"""


from Unet_PRANO_Validate import Validate
